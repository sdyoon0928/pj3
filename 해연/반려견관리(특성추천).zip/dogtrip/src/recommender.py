import pandas as pd
from typing import List, Tuple
from src.preprocess import load_places
from src.schema import DogProfile, OwnerPref
from src.scoring import base_score

def recommend_places(csv_path: str, profile: DogProfile, owner: OwnerPref, top_k: int = 10) -> pd.DataFrame:
    df = load_places(csv_path)
    scores = []
    for _, row in df.iterrows():
        s = base_score(row, profile, owner)
        scores.append(s)
    score_df = pd.DataFrame(scores)
    out = pd.concat([df, score_df], axis=1)

    # 하드 필터: 완전 불가에 가까운 조건 제거
    out = out[out["penalty"] > -9.5]  # deny에 매우 큰 페널티 들어가는 가정

    # 다양성: 타입별 상한선 적용(동일 타입 과몰입 방지)
    out = out.sort_values("total", ascending=False)
    diversified = []
    type_counts = {}
    for _, r in out.iterrows():
        t = r["type"]
        type_counts[t] = type_counts.get(t, 0) + 1
        if type_counts[t] <= 4:  # 타입별 최대 4개
            diversified.append(r)
        if len(diversified) >= top_k:
            break
    return pd.DataFrame(diversified)