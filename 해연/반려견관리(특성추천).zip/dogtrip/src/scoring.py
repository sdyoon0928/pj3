from typing import Dict
import math

FLOOR_SOFT = {"잔디", "흙", "우드칩", "매트", "lawn"}
FLOOR_HARSH = {"자갈", "돌길", "모래", "타일", "데크"}

def clip(v, lo, hi):
    """값을 지정된 범위 [lo, hi]로 제한"""
    return max(lo, min(hi, v))

def map_level(x: str, mapping: Dict[str, float], default=0.5) -> float:
    """문자열 값을 매핑 딕셔너리로 변환, 기본값 반환"""
    return mapping.get(str(x).lower(), default)

def base_score(place, profile, owner) -> Dict[str, float]:
    """장소에 대한 반려견/보호자 프로필 기반 점수 계산"""
    # 하드 필터 페널티(불가 조건 시 큰 마이너스)
    penalty = 0.0
    # 크기 제한
    size_order = {"small": 0, "medium": 1, "large": 2}
    if place.get("size_limit", "unknown") in size_order and profile.size in size_order:
        if size_order[profile.size] > size_order[place["size_limit"]]:
            penalty -= 5.0
    # 반려동물 정책
    if place.get("dog_policy", "unknown") == "deny":
        penalty -= 10.0
    if place.get("dog_policy") == "seasonal_allow" and profile.season not in ["spring", "summer"]:
        penalty -= 2.0
    # 입마개 규정(사회성 낮고 짖음 민감 높으면 불편 점수)
    if place.get("muzzle_rule") == "required" and (profile.social == "low" or profile.bark_sensitive == "high"):
        penalty -= 1.0

    # 활동 적합도
    # 에너지 레벨과 트레일 길이/고도 매칭
    length = float(place.get("length_km", 0.0) or 0.0)
    elev = float(place.get("elevation_gain", 0.0) or 0.0)
    energy_map = {"low": 0.3, "medium": 0.6, "high": 0.9}
    desired = energy_map.get(profile.energy, 0.6)
    length_norm = clip(length / 5.0, 0, 1)  # 5km 기준
    elev_norm = clip(elev / 200.0, 0, 1)   # 200m 기준
    activity_fit = 1.0 - abs(desired - (0.6 * length_norm + 0.4 * elev_norm))

    # 시설/환경 적합도
    has_shade = "그늘" in place["facilities_set"] or place.get("shade_level") in ["medium", "high", "indoor"]
    has_water = ("급수대" in place["facilities_set"]) or (place.get("water_access", "none") not in ["none", "unknown"])
    has_fence = "펜스" in place["facilities_set"]

    facility_score = 0.0
    facility_score += 0.5 if has_shade else 0.0
    facility_score += 0.4 if has_water else 0.0
    facility_score += 0.3 if has_fence else 0.0
    facility_score = clip(facility_score, 0, 1)

    # 사회성/혼잡/소음
    crowd_map = {"low": 0.9, "medium": 0.6, "high": 0.3, "unknown": 0.5}
    noise_map = {"low": 0.9, "medium": 0.6, "high": 0.3, "unknown": 0.5}
    social_pref = {"low": 0.9, "medium": 0.6, "high": 0.3}
    social_fit = 0.5 * crowd_map.get(place.get("crowd_level_est", "unknown"), 0.5) + \
                 0.5 * noise_map.get(place.get("noise_level_est", "unknown"), 0.5)
    social_target = social_pref.get(profile.social, 0.6)
    social_score = 1.0 - abs(social_target - social_fit)

    # 바닥 민감도
    floor_set = place.get("floor_set", set())
    soft_ratio = len(floor_set & FLOOR_SOFT) / max(1, len(floor_set)) if floor_set else 0.5
    harsh_ratio = len(floor_set & FLOOR_HARSH) / max(1, len(floor_set)) if floor_set else 0.0
    paw_score = 0.7 * soft_ratio + 0.3 * (1 - harsh_ratio)
    if profile.paw_sensitive:
        paw_score *= 1.2

    # 계절/날씨 간단 보정(날씨 API 없는 MVP)
    season = profile.season
    season_bonus = 0.0
    if season == "summer":
        season_bonus += 0.2 if has_shade else -0.2
        season_bonus += 0.1 if place.get("water_access", "none") in ["river", "stream", "lake", "sea"] else 0.0
    if season == "winter":
        season_bonus += 0.2 if place.get("type") in ["indoor", "cafe", "stay"] else -0.1

    # 이동 스트레스
    transport_penalty = 0.0
    if profile.transport == "public" and place.get("type") in ["trail", "beach", "camp"]:
        transport_penalty -= 0.3

    # 품종 가중치: 과도하지 않게 ±0.15 내외로 조정
    breed_bonus = 0.0
    breed_name = (getattr(profile, "breed", "") or "").lower()

    if any(k in breed_name for k in ["리트리버", "콜리", "허스키", "셰퍼드"]):
        if length >= 2.5 or elev >= 80:
            breed_bonus += 0.15
    if any(k in breed_name for k in ["말티", "치와", "시추", "비숑", "토이", "푸들", "포메", "믹스"]):
        soft_ok = ("잔디" in floor_set) or ("흙" in floor_set) or ("우드칩" in floor_set) or ("매트" in floor_set)
        if soft_ok:
            breed_bonus += 0.1
        if place.get("crowd_level_est", "medium") in ["low", "medium"]:
            breed_bonus += 0.05
    if any(k in breed_name for k in ["코기", "닥스"]):
        if elev >= 200:
            breed_bonus -= 0.12
    if any(k in breed_name for k in ["허스키", "사모예드"]):
        if season == "summer":
            if has_shade:
                breed_bonus += 0.1
            if place.get("water_access", "none") in ["river", "stream", "lake", "sea"]:
                breed_bonus += 0.1
    if any(k in breed_name for k in ["불독", "퍼그", "프렌치"]):
        if place.get("type") in ["indoor", "cafe", "stay"]:
            breed_bonus += 0.1
        if has_shade:
            breed_bonus += 0.08

    # 총합
    total = 0.35 * activity_fit + 0.3 * facility_score + 0.2 * social_score + 0.15 * paw_score + season_bonus + penalty + transport_penalty + breed_bonus

    return {
        "activity_fit": round(activity_fit, 3),
        "facility_score": round(facility_score, 3),
        "social_score": round(social_score, 3),
        "paw_score": round(paw_score, 3),
        "season_bonus": round(season_bonus, 3),
        "penalty": round(penalty + transport_penalty, 3),
        "breed_bonus": round(breed_bonus, 3),
        "total": round(total, 3)
    }