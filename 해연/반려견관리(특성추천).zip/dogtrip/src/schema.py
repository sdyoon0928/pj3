from dataclasses import dataclass
from typing import Optional

@dataclass
class DogProfile:
    """반려견의 프로필을 정의하는 데이터 클래스"""
    size: str  # small/medium/large
    energy: str  # low/medium/high
    social: str  # low/medium/high
    separation: str  # none/low/medium/high
    bark_sensitive: str  # low/medium/high
    water_love: bool  # 물놀이 선호 여부
    paw_sensitive: bool  # 바닥 민감 여부
    transport: str  # car_short/car_long/public
    max_drive_hours: float  # 최대 운전 시간(시간)
    season: str  # spring/summer/autumn/winter
    breed: Optional[str] = None  # 품종 (선택적)

@dataclass
class OwnerPref:
    """보호자의 선호를 정의하는 데이터 클래스"""
    budget_level: str  # low/mid/high
    activity_level: str  # chill/normal/active
    max_spots: int  # 하루 방문 장소 수
    region_pref: Optional[str] = None  # 선호 지역 (선택적)