import os
from dotenv import load_dotenv
from typing import Dict
from openai import OpenAI

load_dotenv()
client = OpenAI(api_key=os.getenv("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"))

def make_place_summary(place_row: Dict) -> str:
    # 사실 기반 가이드. CSV 컬럼만 사용하도록 지시
    prompt = f""" 너는 반려견 동반 여행 큐레이터야. 아래 장소 정보를 바탕으로 3문장 이내 요약을 만들어줘.

과장 금지, CSV 정보만 근거로 작성
반려견 동반 규정/시설/활동 난이도 중심
마지막에 '현장 정책은 수시로 변경될 수 있어요.' 한 문장 덧붙여
장소 정보: 이름: {place_row.get('name')} 유형: {place_row.get('type')} 지역: {place_row.get('region')} 반려동물 정책: {place_row.get('dog_policy')} 크기 제한: {place_row.get('size_limit')} 목줄 규정: {place_row.get('leash_rule')}, 입마개: {place_row.get('muzzle_rule')} 시설: {place_row.get('facilities')} 바닥: {place_row.get('floor_type')} 길이/고도: {place_row.get('length_km')}km / {place_row.get('elevation_gain')}m 그늘/물: {place_row.get('shade_level')} / {place_row.get('water_access')} 혼잡/소음: {place_row.get('crowd_level_est')} / {place_row.get('noise_level_est')} 링크: {place_row.get('url')}
    """
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.4,
        max_tokens=180,
    )
    return resp.choices[0].message.content.strip()

def make_checklist(season: str, water_love: bool, paw_sensitive: bool) -> str:
    prompt = f""" 반려견 여행 준비물 체크리스트를 간결한 불릿으로 6~8개만 만들어줘. 계절: {season}, 물놀이 선호: {water_love}, 발바닥 민감: {paw_sensitive} 공통 필수품(물/배변도구/목줄 등)은 포함하되, 계절/특성에 따라 2~3개를 커스터마이즈해줘. 과도한 이모지/해시태그는 넣지 마.
    """
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5,
        max_tokens=180,
    )
    return resp.choices[0].message.content.strip()