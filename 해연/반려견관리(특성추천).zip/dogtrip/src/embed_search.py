import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

def build_index(df: pd.DataFrame):
    model = SentenceTransformer(MODEL_NAME)
    texts = []
    for _, r in df.iterrows():
        txt = f"{r['name']} | {r['type']} | {r['region']} | 정책:{r['dog_policy']} | 시설:{r['facilities']} | 바닥:{r['floor_type']} | 그늘:{r['shade_level']} | 물:{r['water_access']} | 혼잡:{r['crowd_level_est']} | 소음:{r['noise_level_est']}"
        texts.append(txt)
    embs = model.encode(texts, convert_to_numpy=True, show_progress_bar=True, normalize_embeddings=True)
    index = faiss.IndexFlatIP(embs.shape[1])
    index.add(embs)
    return model, index, texts

def search(model, index, texts, query: str, top_k=5):
    q = model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    D, I = index.search(q, top_k)
    results = [(int(i), float(D[0][j])) for j, i in enumerate(I[0])]
    return results