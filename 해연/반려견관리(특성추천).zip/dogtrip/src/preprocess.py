import pandas as pd

FACILITY_SET = {"그늘","급수대","펜스"}
FLOOR_SET = {"흙","잔디","모래","자갈","데크","우드칩","타일","매트","돌길","lawn"}

def load_places(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # 결측 보정
    for col in ["dog_policy","size_limit","leash_rule","muzzle_rule","facilities","floor_type","shade_level","water_access","crowd_level_est","noise_level_est","type"]:
        if col in df.columns:
            df[col] = df[col].fillna("unknown")
    # facilities를 세트화
    df["facilities_set"] = df["facilities"].fillna("").apply(lambda x: set(x.split("|")) if isinstance(x,str) and x else set())
    # floor_type을 세트화
    df["floor_set"] = df["floor_type"].fillna("").apply(lambda x: set(x.split("|")) if isinstance(x,str) and x else set())
    # 이동/실내 플래그
    df["is_indoor"] = df["indoor"].astype(str).str.lower().isin(["yes","true","1"])
    df["has_parking"] = df["parking"].astype(str).str.lower().isin(["yes","true","1"])
    # 길이/고도 결측 0
    for col in ["length_km","elevation_gain"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    return df