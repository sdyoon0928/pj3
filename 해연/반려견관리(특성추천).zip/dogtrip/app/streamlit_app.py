import os, sys
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import streamlit as st
import pandas as pd
from src.schema import DogProfile, OwnerPref
from src.recommender import recommend_places
from src.preprocess import load_places
from src.llm_utils import make_place_summary, make_checklist
from src.embed_search import build_index, search

# ===== 화면 표시용 한글 매핑 =====
TYPE_KO_MAP = {
    "trail": "산책로/둘레길",
    "park": "공원",
    "cafe": "카페",
    "stay": "숙소",
    "camp": "캠핑장",
    "indoor": "실내",
    "beach": "해변",
    "unknown": "알 수 없음",
}
DOG_POLICY_KO_MAP = {
    "allow": "동반 가능",
    "deny": "동반 불가",
    "seasonal_allow": "계절 제한 허용",
    "unknown": "미기재",
}
LEASH_RULE_KO_MAP = {
    "required": "목줄 필수",
    "optional": "목줄 선택",
    "unknown": "미기재",
}
MUZZLE_RULE_KO_MAP = {
    "required": "입마개 의무",
    "optional": "입마개 선택",
    "prohibited": "입마개 금지",
    "unknown": "미기재",
}
SIZE_LIMIT_KO_MAP = {
    "small": "소형까지",
    "medium": "중형까지",
    "large": "대형까지",
    "unknown": "미기재",
}

# 입력 컨트롤 매핑
SIZE_LABELS = ["소형", "중형", "대형"]
SIZE_MAP = {"소형": "small", "중형": "medium", "대형": "large"}
LVL_LABELS = ["낮음", "중간", "높음"]
LVL_MAP = {"낮음": "low", "중간": "medium", "높음": "high"}
SEP_LABELS = ["없음", "낮음", "중간", "높음"]
SEP_MAP = {"없음": "none", "낮음": "low", "중간": "medium", "높음": "high"}
TRANSPORT_LABELS = ["승용차(단거리)", "승용차(장거리)", "대중교통"]
TRANSPORT_MAP = {"승용차(단거리)": "car_short", "승용차(장거리)": "car_long", "대중교통": "public"}
SEASON_LABELS = ["봄", "여름", "가을", "겨울"]
SEASON_MAP = {"봄": "spring", "여름": "summer", "가을": "autumn", "겨울": "winter"}
BUDGET_LABELS = ["낮음", "중간", "높음"]
BUDGET_MAP = {"낮음": "low", "중간": "mid", "높음": "high"}
ACTIVITY_LABELS = ["여유로운", "보통", "활동적인"]
ACTIVITY_MAP = {"여유로운": "chill", "보통": "normal", "활동적인": "active"}

# 품종 옵션(샘플)
BREED_OPTIONS = [
    "믹스견", "말티즈", "푸들(토이/미니)", "포메라니안", "치와와", "시추", "닥스훈트",
    "코커 스패니얼", "슈나우저", "비숑", "웰시 코기", "스피츠", "리트리버(골든/래브라도)",
    "사모예드", "보더 콜리", "시베리안 허스키", "진돗개", "풍산개", "불독(프렌치/잉글리시)",
    "시바 이누", "셰퍼드(독일/벨지안)"
]

st.set_page_config(page_title="반려견 맞춤 여행 추천", page_icon="🐶", layout="wide")

st.title("반려견 맞춤 여행 추천 🐾")
st.caption("프로필을 입력하면 반려견에게 딱 맞는 장소를 추천해줄게요!")

@st.cache_resource
def get_index():
    df = load_places("data/places_sample.csv")
    return df, *build_index(df)

with st.sidebar:
    st.header("반려견 프로필")
    breed = st.selectbox("품종", BREED_OPTIONS, index=0)
    size_label = st.selectbox("크기(체형)", SIZE_LABELS, index=1, key="size")
    energy_label = st.select_slider("에너지 레벨", options=LVL_LABELS, value="중간")
    social_label = st.select_slider("사회성", options=LVL_LABELS, value="중간")
    separation_label = st.select_slider("분리불안", options=SEP_LABELS, value="낮음")
    bark_label = st.select_slider("소음 민감/짖음", options=LVL_LABELS, value="중간")
    water_love = st.checkbox("물놀이 좋아해요", value=False)
    paw_sensitive = st.checkbox("발바닥 민감해요", value=False)
    transport_label = st.selectbox("이동 수단", TRANSPORT_LABELS, index=0)
    max_drive_hours = st.slider("최대 운전 시간(시간)", 1.0, 6.0, 3.0, 0.5)
    season_label = st.selectbox("계절", SEASON_LABELS, index=0)

st.header("보호자 선호")
budget_label = st.selectbox("예산", BUDGET_LABELS)
activity_label = st.selectbox("활동 선호", ACTIVITY_LABELS)
max_spots = st.slider("하루 방문 장소 수", 1, 5, 3)
region_pref = st.text_input("선호 지역(예: 서울, 제주, 경기)", "")

profile = DogProfile(
    size=SIZE_MAP[size_label],
    energy=LVL_MAP[energy_label],
    social=LVL_MAP[social_label],
    separation=SEP_MAP[separation_label],
    bark_sensitive=LVL_MAP[bark_label],
    water_love=water_love,
    paw_sensitive=paw_sensitive,
    transport=TRANSPORT_MAP[transport_label],
    max_drive_hours=float(max_drive_hours),
    season=SEASON_MAP[season_label],
    breed=breed,
)
owner = OwnerPref(
    budget_level=BUDGET_MAP[budget_label],
    activity_level=ACTIVITY_MAP[activity_label],
    max_spots=int(max_spots),
    region_pref=region_pref or None,
)

st.subheader("추천 결과")
if st.button("추천 보기"):
    df = recommend_places("data/places_sample.csv", profile, owner, top_k=10)
    if df.empty:
        st.warning("조건에 맞는 장소를 찾지 못했어. 필터를 조금 완화해볼까?")
    else:
        for _, row in df.iterrows():
            with st.container(border=True):
                cols = st.columns([2, 1])
                with cols[0]:
                    type_ko = TYPE_KO_MAP.get(str(row["type"]), str(row["type"]))
                    policy_ko = DOG_POLICY_KO_MAP.get(str(row["dog_policy"]), str(row["dog_policy"]))
                    size_limit_ko = SIZE_LIMIT_KO_MAP.get(str(row["size_limit"]), str(row["size_limit"]))
                    leash_ko = LEASH_RULE_KO_MAP.get(str(row["leash_rule"]), str(row["leash_rule"]))
                    muzzle_ko = MUZZLE_RULE_KO_MAP.get(str(row["muzzle_rule"]), str(row["muzzle_rule"]))

                    st.markdown(f"{row['name']} · {type_ko} · {row['region']}")
                    st.caption(f"선택 품종: {profile.breed}")
                    st.caption(f"정책: {policy_ko} | 크기 제한: {size_limit_ko} | 목줄: {leash_ko} | 입마개: {muzzle_ko}")
                    st.caption(f"시설: {row['facilities']} | 바닥: {row['floor_type']}")
                    st.caption(f"길이/고도: {row['length_km']}km / {row['elevation_gain']}m | 그늘/물: {row['shade_level']} / {row['water_access']}")
                    st.caption(f"혼잡/소음: {row['crowd_level_est']} / {row['noise_level_est']} | 링크: {row['url']}")
                with cols[1]:
                    st.metric("총점", row['total'])
                    st.caption(f"활동 {row['activity_fit']} · 시설 {row['facility_score']} · 사회 {row['social_score']} · 발 {row['paw_score']}")
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("요약 보기", key=f"sum_{row['place_id']}"):
                        st.info(make_place_summary(row.to_dict()))
                with c2:
                    if st.button("준비물 체크리스트", key=f"chk_{row['place_id']}"):
                        st.success(make_checklist(profile.season, profile.water_love, profile.paw_sensitive))

st.subheader("자연어 검색")
query = st.text_input("자연어 검색(예: 조용한 숲길, 그늘 많은 공원)")
if st.button("검색"):
    df, model, index, texts = get_index()
    res = search(model, index, texts, query, top_k=5)
    result_df = df.iloc[[i for i, _ in res]][["name", "type", "region"]].copy()
    result_df["type"] = result_df["type"].apply(lambda x: TYPE_KO_MAP.get(str(x), str(x)))
    result_df.columns = ["이름", "유형", "지역"]
    if result_df.empty:
        st.warning("검색 결과가 없습니다. 다른 검색어를 시도해보세요!")
    else:
        st.write("검색 결과")
        st.dataframe(result_df, use_container_width=True)